# Live-Twitter-Sentiment-Analysis

A Real Time-Twitter-Sentiment-Analysis showcased with the help of Twitter API , NLTK , TextBlob and VADER Sentiment Analyzer.
We extract live tweets about a particular hashtag using TweePy and Pre-process the data using NLTK. 
The cleaned data is then analyzed by the TextBlob sentiment Analyzer to obtain polarity and subjectivity score and VADER Sentiment Analyzer to obtain compound score.
The Sentiment is then visualized in Word Cloud , Donut Chart and some useful textual insights are derived.
